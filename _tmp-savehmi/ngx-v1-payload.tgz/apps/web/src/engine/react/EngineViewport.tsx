
import { Application, Entity } from "@playcanvas/react";
import { Camera } from "@playcanvas/react/components";
import { OrbitControls } from "@playcanvas/react/scripts";
import { getProviderKind } from "@idt/data-adapter";
import type { DeviceBinding, ParsedHmiScene } from "@idt/shared-types";
import { useEffect, useState } from "react";
import { EngineManager } from "../core/EngineManager";
import { DEFAULT_ENGINE_CONFIG } from "../core/EngineConfig";
import { EngineBridge } from "./EngineBridge";
import { DeviceLabels, type DeviceLabelItem } from "./DeviceLabels";
import type { NameplateCommandState } from "../../hooks/useNameplateCommands";
import { SceneLights } from "./SceneLights";
import styles from "./EngineViewport.module.css";

interface EngineViewportProps {
  modelUrl?: string;
  mode: "studio" | "runtime";
  gridEnabled?: boolean;
  selectedNode?: string | null;
  bindings?: DeviceBinding[];
  hmi?: ParsedHmiScene | null;
  emptyText?: string;
  dataLabel?: string;
  labels?: DeviceLabelItem[];
  nameplateCommands?: Record<string, NameplateCommandState>;
  nameplateBusy?: string | null;
  onNameplateStart?: (node: string) => void;
  onNameplateStop?: (node: string) => void;
  onSelect?: (nodeName: string | null) => void;
  onLoaded?: (names: string[]) => void;
  onError?: (message: string) => void;
}

export function EngineViewport(props: EngineViewportProps) {
  const { modelUrl, gridEnabled = true, emptyText = "把模型拖到这里，或点右上角「导入模型」", labels = [] } = props;
  const [kind, setKind] = useState(getProviderKind);

  useEffect(() => {
    const onChange = () => setKind(getProviderKind());
    window.addEventListener("idt-provider-changed", onChange);
    return () => window.removeEventListener("idt-provider-changed", onChange);
  }, []);

  return (
    <div className={styles.wrap}>
      {!modelUrl ? <div className={styles.hint}>{emptyText}</div> : null}
      {modelUrl ? (
        <div className={`${styles.badge} idt-demo-tag`}>
          {props.dataLabel ?? (kind === "guard" ? "后端数据" : "演示数据")}
        </div>
      ) : null}
      <Application fillMode="NONE" resolutionMode="AUTO" graphicsDeviceOptions={{ antialias: true, powerPreference: "high-performance" }}>
        <SceneLights gridEnabled={gridEnabled} />
        <Entity name="camera" position={DEFAULT_ENGINE_CONFIG.cameraPosition}>
          <Camera clearColor={DEFAULT_ENGINE_CONFIG.clearColor} fov={DEFAULT_ENGINE_CONFIG.fov} />
          {/* 默认 distanceMin=18 会把整排总览夹成近景，这里放宽夹紧范围，由 EngineManager 对齐机位 */}
          <OrbitControls distanceMin={1} distanceMax={4000} pitchAngleMax={90} pitchAngleMin={-5} frameOnStart={false} />
        </Entity>
        <EngineBridge {...props} />
      </Application>
      {modelUrl ? (
        <>
          <DeviceLabels
            items={labels}
            selectedNode={props.selectedNode}
            onSelect={(node) => props.onSelect?.(node)}
            commands={props.nameplateCommands}
            busy={props.nameplateBusy}
            onStart={props.onNameplateStart}
            onStop={props.onNameplateStop}
          />
          <button
            type="button"
            className={styles.overviewBtn}
            data-testid="camera-overview"
            onClick={() => EngineManager.instance.refitCamera()}
          >
            总览
          </button>
        </>
      ) : null}
    </div>
  );
}


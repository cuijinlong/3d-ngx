
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { parseHmiGlb } from "@idt/engine-adapter";
import { EngineViewport } from "../../engine/react/EngineViewport";
import { getAsset, readAssetBuffer, resolveAssetUrl } from "../../services/asset/assetService";
import { useAppStore } from "../../stores/app.store";
import { useDeviceStore } from "../../stores/device.store";
import { useSceneStore } from "../../stores/scene.store";
import { useSelectionStore } from "../../stores/selection.store";
import { useTelemetryFeed } from "../../hooks/useTelemetryFeed";
import { AlarmList } from "../alarm/AlarmList";
import { TelemetryPanel } from "../telemetry/TelemetryPanel";
import { useNameplateCommands } from "../../hooks/useNameplateCommands";
import { getProviderKind } from "@idt/data-adapter";
import { bindingsForNode, resolveSceneEntity } from "../../utils/scene-entity";
import { routes } from "../../constants/routes";
import { buildDevicePlates } from "../../utils/device-plates";
import { useTelemetryStore } from "../../stores/telemetry.store";
import { useDemoTelemetry, useTelemetrySource } from "../../hooks/useTelemetrySource";
import { Button, Segmented, Space } from "antd";
import styles from "./RuntimeShell.module.css";

export function RuntimeShell() {
  const nav = useNavigate();
  const document = useSceneStore((s) => s.document);
  const hmi = useSceneStore((s) => s.hmi);
  const setHmi = useSceneStore((s) => s.setHmi);
  const devices = useDeviceStore((s) => s.devices);
  const refresh = useDeviceStore((s) => s.refresh);
  const ready = useAppStore((s) => s.ready);
  const selectedNode = useSelectionStore((s) => s.nodeName);
  const select = useSelectionStore((s) => s.select);
  const [modelUrl, setModelUrl] = useState<string>();
  const [fullscreen, setFullscreen] = useState(false);

  useEffect(() => { if (ready) void refresh(); }, [ready, refresh]);

  useEffect(() => {
    const id = document?.rootAssetId;
    if (!id) { setModelUrl(undefined); return; }
    let cancelled = false;
    (async () => {
      const asset = await getAsset(id);
      if (!asset || cancelled) return;
      setModelUrl(await resolveAssetUrl(asset));
      const parsed = parseHmiGlb(await readAssetBuffer(id));
      if (!cancelled) setHmi(parsed);
    })();
    return () => { cancelled = true; };
  }, [document?.rootAssetId, setHmi]);

  const [telemetrySource, setTelemetrySource] = useTelemetrySource();
  const latest = useTelemetryStore((s) => s.latest);
  const deviceIds = useMemo(() => document?.bindings.map((b) => b.deviceId) ?? [], [document]);
  useTelemetryFeed(telemetrySource === "live" ? deviceIds : []);
  useDemoTelemetry(document?.bindings ?? [], telemetrySource === "demo");
  const labels = buildDevicePlates({
    devices: hmi?.devices ?? [],
    bindings: document?.bindings ?? [],
    latest,
    source: telemetrySource,
  });
  const { stateByNode, busy, send } = useNameplateCommands(labels, document?.bindings ?? []);

  if (!document) return null;

  const binding = bindingsForNode(document, selectedNode)[0];
  const device = devices.find((d) => d.id === binding?.deviceId);
  const dataLabel = telemetrySource === "demo"
    ? "演示数据"
    : getProviderKind() === "guard" ? "后端数据" : "演示数据";

  return (
    <div className={styles.shell}>
      <div className={styles.bar}>
        <span className={styles.title}>{document.scene.name}</span>
        <span className="idt-demo-tag">{dataLabel}</span>
        <span className={styles.grow} />
        <Segmented
          size="small"
          value={telemetrySource}
          onChange={(v) => setTelemetrySource(v as typeof telemetrySource)}
          options={[
            { label: "后端测点", value: "live" },
            { label: "演示数据", value: "demo" },
          ]}
        />
        <Space>
          <Button onClick={() => nav(routes.studioEditor(document.scene.id))}>返回工作室</Button>
          <Button onClick={() => setFullscreen((v) => !v)}>{fullscreen ? "退出全屏布局" : "全屏展示"}</Button>
          <Button onClick={() => void window.document.documentElement.requestFullscreen?.()}>浏览器全屏</Button>
        </Space>
      </div>
      <div className={`${styles.body} ${fullscreen ? styles.full : ""}`}>
        <div className={styles.view}>
          <EngineViewport
            mode="runtime"
            modelUrl={modelUrl}
            gridEnabled={false}
            selectedNode={selectedNode}
            bindings={document.bindings}
            hmi={hmi}
            emptyText="该场景还没有导入模型"
            labels={labels}
            dataLabel={dataLabel}
            nameplateCommands={stateByNode}
            nameplateBusy={busy}
            onNameplateStart={(node) => void send(node, "start")}
            onNameplateStop={(node) => void send(node, "stop")}
            onSelect={(name) => {
              const entity = resolveSceneEntity(document, name);
              select(entity?.id ?? name, entity?.nodeName ?? name);
            }}
          />
        </div>
        <aside className={styles.side}>
          <TelemetryPanel device={device} binding={binding} />
          <AlarmList />
        </aside>
      </div>
    </div>
  );
}


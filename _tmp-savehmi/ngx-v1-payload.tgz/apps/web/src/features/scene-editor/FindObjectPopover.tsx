
import { Button, Input, Popover } from "antd";
import { useMemo, useState } from "react";
import type { ParsedHmiScene } from "@idt/shared-types";
import { uniqueEntitiesFromParsed } from "../../utils/hmi-entities";

export function FindObjectPopover({
  hmi,
  onPick,
}: {
  hmi: ParsedHmiScene | null;
  onPick: (node: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const items = useMemo(() => (hmi ? uniqueEntitiesFromParsed(hmi) : []), [hmi]);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((item) => item.name.toLowerCase().includes(q) || item.node.toLowerCase().includes(q));
  }, [items, query]);

  return (
    <Popover
      trigger="click"
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) setQuery("");
      }}
      placement="bottomLeft"
      content={
        <div style={{ width: 280 }} data-testid="find-object-list">
          <Input
            autoFocus
            allowClear
            placeholder="查找画面对象"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <div style={{ maxHeight: 320, overflow: "auto", marginTop: 8 }}>
            {filtered.length === 0 ? (
              <div style={{ color: "#5f6e84", fontSize: 13, padding: "8px 0" }}>没有匹配的对象</div>
            ) : (
              filtered.map((item) => (
                <Button
                  key={item.node}
                  type="text"
                  block
                  style={{ textAlign: "left", height: 32 }}
                  onClick={() => {
                    onPick(item.node);
                    setOpen(false);
                    setQuery("");
                  }}
                >
                  {item.name}
                </Button>
              ))
            )}
          </div>
        </div>
      }
    >
      <Button data-testid="find-object">查找画面对象</Button>
    </Popover>
  );
}
